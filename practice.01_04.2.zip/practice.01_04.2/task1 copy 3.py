p, q = map(int, input().split())
print(p, q)
p, q = q, p
print(p, q)