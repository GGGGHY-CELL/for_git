title = "Закулисье реальности"
year = 2026
rating = "8.9"
print(title, "-", year, "-", rating)