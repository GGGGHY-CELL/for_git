x = 8
y = x - 3
x = (x + y) * 2
y = y + x
print(x, y)
# Мой ответ: 26, 31