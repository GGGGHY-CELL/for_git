const = 92.5
sum = int(input())
print("{:.2f}".format(sum / const))
print(int(sum // const))
print(float(sum % const))