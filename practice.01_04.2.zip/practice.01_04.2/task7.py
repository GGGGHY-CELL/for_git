a, b = map(int, input().split())
final = (a + b) / 2
print(f"Среднее: {final}")