k = int(input())
print("{:4d}".format(k))
print("{:4d}".format(k + 1))
print("{:4d}".format(k + 2))