a = 20
b = 4
a -= 7
b *= 3
print(a, b)
a /= b
print(f"a = {a}, b = {b}")