city = input("The city you born in: ")
hobby = input("The hobby you like: ")
print(f"I was born in {city}, and my hobby is {hobby}")