print(144/12)
print(7**3)
print(50 - 18 * 2)
print((10 + 5) * 2 - 8)
