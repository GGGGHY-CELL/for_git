m, n, k = map(int, input().split())
print((m ** 2 + n) / (k - 1))