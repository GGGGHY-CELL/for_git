x = 37
y = 8
print(f"x / y")
print(f"x // y")
print(f"x % y")
print(f"x // y * y + x % y")