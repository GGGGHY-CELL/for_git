a = int(input("Первое число: "))
b = int(input("Второе число: "))
print(f"Разность: {a - b}")